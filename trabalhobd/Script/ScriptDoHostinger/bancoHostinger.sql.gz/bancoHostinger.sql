-- MySQL dump 10.16  Distrib 10.1.22-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: u114118567_banc2
-- ------------------------------------------------------
-- Server version	10.1.22-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auxiliar`
--

DROP TABLE IF EXISTS `auxiliar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auxiliar` (
  `Nome` varchar(50) NOT NULL,
  `ComissaoTecnicaEquipe` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Nome`),
  KEY `FkComissaoEquipe_idx` (`ComissaoTecnicaEquipe`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auxiliar`
--

/*!40000 ALTER TABLE `auxiliar` DISABLE KEYS */;
INSERT INTO `auxiliar` VALUES ('julismandro','julisFCasas'),('Jonilson','ZRRO');
/*!40000 ALTER TABLE `auxiliar` ENABLE KEYS */;

--
-- Table structure for table `comissaotecnica`
--

DROP TABLE IF EXISTS `comissaotecnica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comissaotecnica` (
  `NomeEquipe` varchar(45) NOT NULL,
  `NomeTecnico` varchar(50) NOT NULL,
  `NomeAuxiliar` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`NomeEquipe`),
  KEY `FkNomeEquipe_idx` (`NomeEquipe`),
  KEY `FkNomeTecnico_idx` (`NomeTecnico`),
  KEY `FkNomeAuxiliar_idx` (`NomeAuxiliar`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comissaotecnica`
--

/*!40000 ALTER TABLE `comissaotecnica` DISABLE KEYS */;
/*!40000 ALTER TABLE `comissaotecnica` ENABLE KEYS */;

--
-- Table structure for table `competicao`
--

DROP TABLE IF EXISTS `competicao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `competicao` (
  `Nome` varchar(30) NOT NULL,
  `Abrangencia` varchar(8) DEFAULT NULL,
  `SistemaPontuacao` varchar(15) DEFAULT NULL,
  `Serie` char(1) DEFAULT NULL COMMENT 'Chave primaria é sublinhada e estrangeira não. ',
  `NomeEntidade` varchar(20) NOT NULL,
  `QuantidadeDeJogos` int(11) DEFAULT NULL,
  `Ano` date NOT NULL,
  PRIMARY KEY (`Nome`,`Ano`),
  KEY `FkNomeEntidade_idx` (`NomeEntidade`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `competicao`
--

/*!40000 ALTER TABLE `competicao` DISABLE KEYS */;
/*!40000 ALTER TABLE `competicao` ENABLE KEYS */;

--
-- Table structure for table `competicaoequipe`
--

DROP TABLE IF EXISTS `competicaoequipe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `competicaoequipe` (
  `Posicao` int(2) DEFAULT NULL,
  `NomeEquipe` varchar(45) NOT NULL,
  `NomeDaCompeticao` varchar(30) NOT NULL,
  `Pontuacao` int(3) DEFAULT NULL,
  `GolsFavor` int(2) DEFAULT NULL,
  `GolsContra` int(2) DEFAULT NULL,
  PRIMARY KEY (`NomeEquipe`,`NomeDaCompeticao`),
  KEY `FkNomeEquipe_idx` (`NomeEquipe`),
  KEY `FkNomeCompeticao_idx` (`NomeDaCompeticao`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `competicaoequipe`
--

/*!40000 ALTER TABLE `competicaoequipe` DISABLE KEYS */;
/*!40000 ALTER TABLE `competicaoequipe` ENABLE KEYS */;

--
-- Table structure for table `entidade`
--

DROP TABLE IF EXISTS `entidade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entidade` (
  `Nome` varchar(50) NOT NULL,
  `TerritorioDeAbrangencia` varchar(10) DEFAULT NULL,
  `Tipo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Nome`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entidade`
--

/*!40000 ALTER TABLE `entidade` DISABLE KEYS */;
/*!40000 ALTER TABLE `entidade` ENABLE KEYS */;

--
-- Table structure for table `equipe`
--

DROP TABLE IF EXISTS `equipe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipe` (
  `Nome` varchar(45) NOT NULL,
  `Estado` varchar(20) DEFAULT NULL,
  `NomeEstadio` varchar(50) NOT NULL,
  `NomeTecnico` varchar(50) NOT NULL,
  PRIMARY KEY (`Nome`),
  KEY `FkNomeEstadio_idx` (`NomeEstadio`),
  KEY `FkNomeTecnico_idx` (`NomeTecnico`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipe`
--

/*!40000 ALTER TABLE `equipe` DISABLE KEYS */;
INSERT INTO `equipe` VALUES ('Juventus','São Paulo','Riacho','Empada');
/*!40000 ALTER TABLE `equipe` ENABLE KEYS */;

--
-- Table structure for table `equipedearbitragem`
--

DROP TABLE IF EXISTS `equipedearbitragem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipedearbitragem` (
  `Id` int(11) NOT NULL,
  `NomeBanderinha1` varchar(50) NOT NULL,
  `NomeBandeirinha2` varchar(50) DEFAULT NULL,
  `NomeArbitro` varchar(50) DEFAULT NULL,
  `NomeQuartoArbitro` varchar(50) DEFAULT NULL,
  `NomeEntidade` varchar(50) NOT NULL,
  `Delegado` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FkNomeEntidade_idx` (`NomeEntidade`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipedearbitragem`
--

/*!40000 ALTER TABLE `equipedearbitragem` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipedearbitragem` ENABLE KEYS */;

--
-- Table structure for table `estadio`
--

DROP TABLE IF EXISTS `estadio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estadio` (
  `Nome` varchar(50) NOT NULL,
  `Capacidade` int(11) DEFAULT NULL,
  `Cidade` varchar(30) DEFAULT NULL,
  `Estado` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Nome`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estadio`
--

/*!40000 ALTER TABLE `estadio` DISABLE KEYS */;
/*!40000 ALTER TABLE `estadio` ENABLE KEYS */;

--
-- Table structure for table `jogador`
--

DROP TABLE IF EXISTS `jogador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jogador` (
  `Posicao` varchar(15) DEFAULT NULL,
  `Nome` varchar(50) DEFAULT NULL,
  `DataNasc` date DEFAULT NULL,
  `Camisa` int(3) NOT NULL,
  `NomeEquipe` varchar(45) NOT NULL,
  PRIMARY KEY (`Camisa`,`NomeEquipe`),
  KEY `FkEquipe_idx` (`NomeEquipe`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jogador`
--

/*!40000 ALTER TABLE `jogador` DISABLE KEYS */;
INSERT INTO `jogador` VALUES ('Zagueiro(a)','Afonso','2017-05-09',5,'Barcelona'),('Zagueiro(a)','Vias','2013-05-27',97,'Reino');
/*!40000 ALTER TABLE `jogador` ENABLE KEYS */;

--
-- Table structure for table `partida`
--

DROP TABLE IF EXISTS `partida`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partida` (
  `IDPartida` int(11) NOT NULL,
  `IDEquipeArbitragem` int(11) NOT NULL,
  `NomeEntidade` varchar(50) NOT NULL,
  `Data` date DEFAULT NULL,
  `Hora` time DEFAULT NULL,
  `ResultadoFinal` varchar(5) DEFAULT NULL COMMENT 'Resultado dos gols da partida.\nEstá tendo problema com gols marcados e sofridos.',
  `EquipeVencedora` varchar(45) DEFAULT NULL,
  `DisputaDePenaltis` tinyint(1) DEFAULT '0',
  `GolQualificado` tinyint(1) DEFAULT '0',
  `NomeCompeticao` varchar(30) DEFAULT NULL,
  `NomeEquipe` varchar(45) NOT NULL,
  `NomeEstadio` varchar(50) NOT NULL,
  PRIMARY KEY (`IDPartida`),
  KEY `FkNomeEntindade_idx` (`NomeEntidade`),
  KEY `FkNomeCompeticao_idx` (`NomeCompeticao`),
  KEY `FkNomeEquipe_idx` (`NomeEquipe`),
  KEY `FkEquipeDeArbitragem_idx` (`IDEquipeArbitragem`),
  KEY `FkNomeEstadio_idx` (`NomeEstadio`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partida`
--

/*!40000 ALTER TABLE `partida` DISABLE KEYS */;
/*!40000 ALTER TABLE `partida` ENABLE KEYS */;

--
-- Table structure for table `tecnico`
--

DROP TABLE IF EXISTS `tecnico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tecnico` (
  `Nome` varchar(50) NOT NULL,
  `Equipe` varchar(45) NOT NULL,
  PRIMARY KEY (`Nome`,`Equipe`),
  KEY `FkNomeComissaoTecEqui_idx` (`Equipe`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tecnico`
--

/*!40000 ALTER TABLE `tecnico` DISABLE KEYS */;
/*!40000 ALTER TABLE `tecnico` ENABLE KEYS */;

--
-- Table structure for table `transferencias`
--

DROP TABLE IF EXISTS `transferencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transferencias` (
  `Camisa` int(3) NOT NULL,
  `NomeEquipe$` varchar(30) NOT NULL,
  `EquipeTransfereJogadorcol` varchar(45) DEFAULT NULL,
  `JogadorNomeEquipeAnterior` varchar(45) DEFAULT NULL,
  `ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `FkNomeEquipe_idx` (`NomeEquipe$`),
  KEY `FkCamisa_idx` (`Camisa`),
  KEY `FkNomeEquipeJogadorAtual_idx` (`JogadorNomeEquipeAnterior`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transferencias`
--

/*!40000 ALTER TABLE `transferencias` DISABLE KEYS */;
/*!40000 ALTER TABLE `transferencias` ENABLE KEYS */;

--
-- Dumping events for database 'u114118567_banc2'
--

--
-- Dumping routines for database 'u114118567_banc2'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-19 16:44:09
